using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bomb : MonoBehaviour
{
    public int damage = 50;
    public void Fire()
    {
        Debug.Log("Machine Gun " + 50);
    }
}
