using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ICoinView
{
    public void UpdateCoinsAmount(int amount);
}
