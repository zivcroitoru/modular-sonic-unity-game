using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IWeaponReload : IWeapon
{
    void Reload();  
}
