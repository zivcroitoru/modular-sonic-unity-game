using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Adds IsGrounded() to any Transform
public static class GroundedExtension
{
    // Checks if touching ground
    public static bool IsGrounded(this Transform transform, LayerMask groundLayer)
    {
        // Point below the player
        Vector2 point = new Vector2(transform.position.x, transform.position.y - 0.5f);

        // Check if ground is at that point
        bool isGrounded = Physics2D.OverlapArea(point, point, groundLayer);

        // Return result
        return isGrounded;
    }
}
