# Editor Rich Presence
## A Discord Rich Presence for the Unity editor

![Unity Asset Store Image](https://assetstorev1-prd-cdn.unity3d.com/key-image/d514aa2a-ca58-4a63-9ae0-b27239e1f8d8.webp)

Show off what you're working on in unity with Editor Rich Presence on discord.

![Example Image](https://assetstorev1-prd-cdn.unity3d.com/package-screenshot/d7c67997-ea03-4881-ae7c-41f15296513a.webp)

## Download

You can now download Editor Rich Presence from the Unity Asset store from [here](https://assetstore.unity.com/packages/tools/utilities/editor-rich-presence-178736)!

## Warning

This package makes a `.erp` file in the root of the project if you don't want this to be shared in a git repo add it to your ignore list.
